import React from "react"
import "./homepage.css"

const Homepage = ({setLoginUser}) => {
    return (
        <div className="homepage">
            <a href="http://localhost:3006" target="_blank" > <h1>HomePage</h1></a>
           <a href="http://localhost:3000" target="_blank" > <h1>CrudApp</h1></a>
            <div className="button" onClick={() => setLoginUser({})} >Logout</div>
        </div>
    )
}

export default Homepage